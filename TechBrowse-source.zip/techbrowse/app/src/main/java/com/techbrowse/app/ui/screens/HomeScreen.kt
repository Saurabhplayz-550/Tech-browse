package com.techbrowse.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.techbrowse.app.data.local.HistoryEntity
import com.techbrowse.app.util.hostLabel

data class Shortcut(val label: String, val url: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val tint: Color)

private val shortcuts = listOf(
    Shortcut("Google", "https://www.google.com", Icons.Filled.Search, Color(0xFF4285F4)),
    Shortcut("YouTube", "https://www.youtube.com", Icons.Filled.PlayArrow, Color(0xFFFF0000)),
    Shortcut("ChatGPT", "https://chat.openai.com", Icons.Filled.SmartToy, Color(0xFF10A37F)),
    Shortcut("Gmail", "https://mail.google.com", Icons.Filled.MailOutline, Color(0xFFEA4335))
)

@Composable
fun HomeScreen(
    recentHistory: List<HistoryEntity>,
    onSearch: (String) -> Unit,
    onShortcutClick: (String) -> Unit,
    onHistoryItemClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item { Spacer(Modifier.height(32.dp)) }

        item {
            Text(
                text = "Tech Browse",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(20.dp))
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search or type a URL") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    imeAction = androidx.compose.ui.text.input.ImeAction.Go
                ),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onGo = { if (query.isNotBlank()) onSearch(query) }
                )
            )
            Spacer(Modifier.height(24.dp))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                shortcuts.forEach { shortcut ->
                    ShortcutButton(shortcut) { onShortcutClick(shortcut.url) }
                }
            }
            Spacer(Modifier.height(28.dp))
        }

        if (recentHistory.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(0.dp))
                    Text(
                        "  Recently visited",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
            items(recentHistory.distinctBy { it.url }.take(10)) { entry ->
                Card(
                    onClick = { onHistoryItemClick(entry.url) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            entry.title.ifBlank { hostLabel(entry.url) },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            hostLabel(entry.url),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(40.dp)) }
    }
}

@Composable
private fun ShortcutButton(shortcut: Shortcut, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = CircleShape,
            color = shortcut.tint.copy(alpha = 0.15f),
            modifier = Modifier.height(56.dp)
        ) {
            androidx.compose.material3.IconButton(onClick = onClick) {
                Icon(shortcut.icon, contentDescription = shortcut.label, tint = shortcut.tint)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(shortcut.label, style = MaterialTheme.typography.labelLarge)
    }
}
