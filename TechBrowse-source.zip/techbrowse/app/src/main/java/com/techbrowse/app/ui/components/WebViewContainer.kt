package com.techbrowse.app.ui.components

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.getSystemService

/**
 * Callbacks fed back up to the ViewModel/screen as the WebView's state changes.
 */
data class WebViewCallbacks(
    val onPageStarted: () -> Unit,
    val onProgressChanged: (Int) -> Unit,
    val onPageFinished: (url: String, title: String?) -> Unit,
    val onNewTabRequested: (url: String) -> Unit,
    val onShowFullscreenVideo: (android.view.View, WebChromeClient.CustomViewCallback) -> Unit,
    val onHideFullscreenVideo: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebViewContainer(
    tabId: String,
    initialUrl: String,
    getOrCreateWebView: (String, Context) -> WebView,
    callbacks: WebViewCallbacks,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isRefreshing by remember { mutableStateOf(false) }
    val pullState = rememberPullToRefreshState()
    val latestCallbacks by rememberUpdatedState(callbacks)

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = {
            isRefreshing = true
            getOrCreateWebView(tabId, context).reload()
        },
        state = pullState,
        modifier = modifier.fillMaxSize()
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = {
                val webView = getOrCreateWebView(tabId, context)
                configureWebView(webView, latestCallbacks) { isRefreshing = false }
                (webView.parent as? ViewGroup)?.removeView(webView)
                webView
            },
            update = { webView ->
                (webView.parent as? ViewGroup)?.let { parent ->
                    if (parent !is FrameLayout || parent.getChildAt(0) != webView) {
                        parent.removeView(webView)
                    }
                }
                if (webView.url.isNullOrBlank() && initialUrl.isNotBlank()) {
                    webView.loadUrl(initialUrl)
                }
            }
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun configureWebView(
    webView: WebView,
    callbacks: WebViewCallbacks,
    onRefreshDone: () -> Unit
) {
    webView.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        loadWithOverviewMode = true
        useWideViewPort = true
        builtInZoomControls = true
        displayZoomControls = false
        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        mediaPlaybackRequiresUserGesture = false
        cacheMode = WebSettings.LOAD_DEFAULT
    }
    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

    webView.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView,
            request: android.webkit.WebResourceRequest
        ): Boolean {
            val url = request.url.toString()
            return if (url.startsWith("http://") || url.startsWith("https://")) {
                false // let this WebView load it (covers "open link in same tab")
            } else {
                // mailto:, tel:, intent:// etc — hand off to the system
                try {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, request.url)
                    view.context.startActivity(intent)
                } catch (_: Exception) { /* no handler available */ }
                true
            }
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            callbacks.onPageStarted()
        }

        override fun onPageFinished(view: WebView, url: String) {
            onRefreshDone()
            callbacks.onPageFinished(url, view.title)
        }
    }

    webView.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            callbacks.onProgressChanged(newProgress)
        }

        // Full-screen <video> support
        override fun onShowCustomView(view: android.view.View, callback: CustomViewCallback) {
            callbacks.onShowFullscreenVideo(view, callback)
        }

        override fun onHideCustomView() {
            callbacks.onHideFullscreenVideo()
        }

        override fun onCreateWindow(
            view: WebView,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: android.os.Message
        ): Boolean {
            // target="_blank" links -> open as a new tab instead of a popup window
            val href = view.hitTestResult.extra
            if (!href.isNullOrBlank()) callbacks.onNewTabRequested(href)
            return false
        }
    }

    webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                addRequestHeader("cookie", CookieManager.getInstance().getCookie(url))
                setMimeType(mimeType)
            }
            val dm = webView.context.getSystemService<DownloadManager>()
            dm?.enqueue(request)
            Toast.makeText(webView.context, "Downloading $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(webView.context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
