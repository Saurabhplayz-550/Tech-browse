package com.techbrowse.app

import android.app.Application
import com.techbrowse.app.data.local.AppDatabase
import com.techbrowse.app.data.prefs.PreferencesManager
import com.techbrowse.app.data.repository.BrowserRepository

class TechBrowseApp : Application() {

    lateinit var repository: BrowserRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        val prefs = PreferencesManager(this)
        repository = BrowserRepository(db, prefs)
    }
}
