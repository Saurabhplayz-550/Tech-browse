package com.techbrowse.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "techbrowse_settings")

enum class SearchEngine(val label: String, val queryUrl: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q=")
}

/**
 * Persists: theme preference, default search engine, and last-open-tabs (as JSON).
 */
class PreferencesManager(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode") // "system" | "light" | "dark"
        val SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val LAST_TABS_JSON = stringPreferencesKey("last_tabs_json")
    }

    val themeMode: Flow<String> = context.dataStore.data.map { it[Keys.THEME] ?: "system" }

    val searchEngine: Flow<SearchEngine> = context.dataStore.data.map {
        SearchEngine.valueOf(it[Keys.SEARCH_ENGINE] ?: SearchEngine.GOOGLE.name)
    }

    val lastTabsJson: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_TABS_JSON] }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[Keys.THEME] = mode }
    }

    suspend fun setSearchEngine(engine: SearchEngine) {
        context.dataStore.edit { it[Keys.SEARCH_ENGINE] = engine.name }
    }

    suspend fun setLastTabsJson(json: String) {
        context.dataStore.edit { it[Keys.LAST_TABS_JSON] = json }
    }

    suspend fun clearLastTabs() {
        context.dataStore.edit { it.remove(Keys.LAST_TABS_JSON) }
    }
}
