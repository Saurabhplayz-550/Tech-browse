package com.techbrowse.app.viewmodel

import android.webkit.WebView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.techbrowse.app.data.local.BookmarkEntity
import com.techbrowse.app.data.local.HistoryEntity
import com.techbrowse.app.data.model.BrowserTab
import com.techbrowse.app.data.prefs.SearchEngine
import com.techbrowse.app.data.repository.BrowserRepository
import com.techbrowse.app.util.resolveInput
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

/**
 * Central ViewModel: owns tab metadata + WebView instances, navigation state,
 * and bridges to the repository for bookmarks/history/settings persistence.
 */
class BrowserViewModel(private val repository: BrowserRepository) : ViewModel() {

    // ---- Tabs ----
    private val _tabs = MutableStateFlow<List<BrowserTab>>(emptyList())
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow<String?>(null)
    val activeTabId: StateFlow<String?> = _activeTabId.asStateFlow()

    // Real WebView instances, keyed by tab id. Owned here so tabs survive
    // navigation between Home/Browser/Settings screens.
    private val webViews = mutableMapOf<String, WebView>()

    // ---- Per-tab transient nav state (progress/back/forward) ----
    private val _progress = MutableStateFlow(0)
    val progress: StateFlow<Int> = _progress.asStateFlow()

    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    private val _canGoForward = MutableStateFlow(false)
    val canGoForward: StateFlow<Boolean> = _canGoForward.asStateFlow()

    private val _isBookmarked = MutableStateFlow(false)
    val isBookmarked: StateFlow<Boolean> = _isBookmarked.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // ---- Settings (from repository) ----
    val themeMode: StateFlow<String> = repository.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, "system")

    val searchEngine: StateFlow<SearchEngine> = repository.searchEngine
        .stateIn(viewModelScope, SharingStarted.Eagerly, SearchEngine.GOOGLE)

    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.bookmarks()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val history: StateFlow<List<HistoryEntity>> = repository.recentHistory()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        restoreTabsOrCreateDefault()
    }

    private fun restoreTabsOrCreateDefault() {
        viewModelScope.launch {
            val json = repository.lastTabsJson.first()
            val restored = try {
                json?.let { Json.decodeFromString<List<BrowserTab>>(it) }
            } catch (e: Exception) {
                null
            }
            if (!restored.isNullOrEmpty()) {
                _tabs.value = restored
                _activeTabId.value = restored.first().id
            } else {
                addTab()
            }
        }
    }

    fun registerWebView(tabId: String, webView: WebView) {
        webViews[tabId] = webView
    }

    fun getWebView(tabId: String): WebView? = webViews[tabId]

    fun addTab(initialUrl: String? = null): String {
        val id = UUID.randomUUID().toString()
        val tab = BrowserTab(id = id, url = initialUrl ?: "", isHome = initialUrl == null)
        _tabs.value = _tabs.value + tab
        _activeTabId.value = id
        persistTabs()
        return id
    }

    fun closeTab(tabId: String) {
        webViews.remove(tabId)?.destroy()
        val remaining = _tabs.value.filterNot { it.id == tabId }
        _tabs.value = remaining
        if (_activeTabId.value == tabId) {
            _activeTabId.value = remaining.lastOrNull()?.id
        }
        if (remaining.isEmpty()) addTab()
        persistTabs()
    }

    fun switchTab(tabId: String) {
        _activeTabId.value = tabId
        val tab = _tabs.value.find { it.id == tabId }
        _isBookmarked.value = false
        viewModelScope.launch {
            tab?.let { _isBookmarked.value = repository.isBookmarked(it.url) }
        }
    }

    fun navigate(input: String) {
        val activeId = _activeTabId.value ?: addTab()
        val target = resolveInput(input, searchEngine.value)
        updateActiveTab { it.copy(url = target, isHome = false) }
        webViews[activeId]?.loadUrl(target)
    }

    fun goHome() {
        val activeId = _activeTabId.value ?: return
        updateActiveTab { it.copy(url = "", isHome = true) }
        webViews[activeId]?.loadUrl("about:blank")
    }

    fun goBack(): Boolean {
        val wv = _activeTabId.value?.let { webViews[it] } ?: return false
        return if (wv.canGoBack()) { wv.goBack(); true } else false
    }

    fun goForward() {
        _activeTabId.value?.let { webViews[it] }?.let { if (it.canGoForward()) it.goForward() }
    }

    fun refresh() {
        _activeTabId.value?.let { webViews[it] }?.reload()
    }

    fun onPageStarted() {
        _isLoading.value = true
        _progress.value = 5
    }

    fun onProgressChanged(p: Int) {
        _progress.value = p
    }

    fun onPageFinished(url: String, title: String?) {
        _isLoading.value = false
        _progress.value = 100
        updateActiveTab { it.copy(url = url, title = title ?: it.title, isHome = url == "about:blank") }
        val wv = _activeTabId.value?.let { webViews[it] }
        _canGoBack.value = wv?.canGoBack() ?: false
        _canGoForward.value = wv?.canGoForward() ?: false
        viewModelScope.launch {
            repository.recordVisit(title ?: url, url)
            _isBookmarked.value = repository.isBookmarked(url)
        }
        persistTabs()
    }

    fun toggleBookmark() {
        val tab = currentTab() ?: return
        if (tab.url.isBlank()) return
        viewModelScope.launch {
            repository.toggleBookmark(tab.title, tab.url)
            _isBookmarked.value = repository.isBookmarked(tab.url)
        }
    }

    fun removeBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch { repository.removeBookmark(bookmark) }
    }

    fun clearHistory() {
        viewModelScope.launch { repository.clearHistory() }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setSearchEngine(engine: SearchEngine) {
        viewModelScope.launch { repository.setSearchEngine(engine) }
    }

    fun currentTab(): BrowserTab? = _tabs.value.find { it.id == _activeTabId.value }

    private fun updateActiveTab(transform: (BrowserTab) -> BrowserTab) {
        val id = _activeTabId.value ?: return
        _tabs.value = _tabs.value.map { if (it.id == id) transform(it) else it }
    }

    private fun persistTabs() {
        viewModelScope.launch {
            try {
                repository.saveLastTabs(Json.encodeToString(_tabs.value))
            } catch (_: Exception) { /* best-effort persistence */ }
        }
    }

    override fun onCleared() {
        super.onCleared()
        webViews.values.forEach { it.destroy() }
        webViews.clear()
    }
}
