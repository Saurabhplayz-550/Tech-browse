package com.techbrowse.app.ui.theme

import androidx.compose.ui.graphics.Color

// Blue theme palette
val BluePrimaryLight = Color(0xFF1A73E8)
val BlueOnPrimaryLight = Color(0xFFFFFFFF)
val BluePrimaryContainerLight = Color(0xFFD3E3FD)
val BlueSecondaryLight = Color(0xFF3C6E9C)
val BlueBackgroundLight = Color(0xFFF8FAFD)
val BlueSurfaceLight = Color(0xFFFFFFFF)
val BlueOnSurfaceLight = Color(0xFF1A1C1E)

val BluePrimaryDark = Color(0xFF9EC7FF)
val BlueOnPrimaryDark = Color(0xFF00315F)
val BluePrimaryContainerDark = Color(0xFF1E4876)
val BlueSecondaryDark = Color(0xFFA8CBEB)
val BlueBackgroundDark = Color(0xFF111318)
val BlueSurfaceDark = Color(0xFF111318)
val BlueOnSurfaceDark = Color(0xFFE2E2E6)
