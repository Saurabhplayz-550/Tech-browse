package com.techbrowse.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class BrowserTab(
    val id: String,
    var title: String = "New Tab",
    var url: String = "",
    var isHome: Boolean = true
)
