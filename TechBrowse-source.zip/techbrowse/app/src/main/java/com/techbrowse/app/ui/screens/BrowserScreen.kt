package com.techbrowse.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import com.techbrowse.app.ui.components.AddressBar
import com.techbrowse.app.ui.components.TabStrip
import com.techbrowse.app.ui.components.WebViewCallbacks
import com.techbrowse.app.ui.components.WebViewContainer
import com.techbrowse.app.viewmodel.BrowserViewModel

@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    onOpenHome: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isBookmarked by viewModel.isBookmarked.collectAsState()
    val currentTab = tabs.find { it.id == activeTabId }

    // Full-screen video overlay state (for <video> fullscreen playback)
    var fullscreenView by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<View?>(null) }
    var fullscreenCallback by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<WebChromeClient.CustomViewCallback?>(null)
    }

    val callbacks = WebViewCallbacks(
        onPageStarted = { viewModel.onPageStarted() },
        onProgressChanged = { viewModel.onProgressChanged(it) },
        onPageFinished = { url, title -> viewModel.onPageFinished(url, title) },
        onNewTabRequested = { url -> viewModel.addTab(url) },
        onShowFullscreenVideo = { view, callback ->
            fullscreenView = view
            fullscreenCallback = callback
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        },
        onHideFullscreenVideo = {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            fullscreenView = null
            fullscreenCallback?.onCustomViewHidden()
            fullscreenCallback = null
        }
    )

    var showLibrarySheet by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var showOverflowMenu by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    val canGoBackState by viewModel.canGoBack.collectAsState()
    androidx.activity.compose.BackHandler(enabled = true) {
        when {
            canGoBackState -> viewModel.goBack()
            currentTab != null && !currentTab.isHome -> onOpenHome()
            else -> activity?.finish()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                Column {
                    androidx.compose.foundation.layout.Row(
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        TabStrip(
                            tabs = tabs,
                            activeTabId = activeTabId,
                            onTabSelected = { viewModel.switchTab(it) },
                            onTabClosed = { viewModel.closeTab(it) },
                            onNewTab = { viewModel.addTab() },
                            modifier = Modifier.weight(1f)
                        )
                        Box {
                            IconButton(onClick = { showOverflowMenu = true }) {
                                Icon(androidx.compose.material.icons.Icons.Filled.MoreVert, contentDescription = "More options")
                            }
                            androidx.compose.material3.DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false }
                            ) {
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { androidx.compose.material3.Text("Bookmarks & History") },
                                    onClick = { showOverflowMenu = false; showLibrarySheet = true }
                                )
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { androidx.compose.material3.Text("Settings") },
                                    onClick = { showOverflowMenu = false; onOpenSettings() }
                                )
                            }
                        }
                    }
                    AddressBar(
                        currentUrl = currentTab?.url.orEmpty(),
                        isBookmarked = isBookmarked,
                        onSubmit = { viewModel.navigate(it) },
                        onBookmarkToggle = { viewModel.toggleBookmark() }
                    )
                    if (isLoading) {
                        LinearProgressIndicator(
                            progress = { progress / 100f },
                            modifier = Modifier.fillMaxWidth().height(2.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            bottomBar = {
                Surface(color = MaterialTheme.colorScheme.surface) {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly
                    ) {
                        val canGoBack by viewModel.canGoBack.collectAsState()
                        val canGoForward by viewModel.canGoForward.collectAsState()

                        IconButton(onClick = { viewModel.goBack() }, enabled = canGoBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                        IconButton(onClick = { viewModel.goForward() }, enabled = canGoForward) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Forward")
                        }
                        IconButton(onClick = onOpenHome) {
                            Icon(Icons.Filled.Home, contentDescription = "Home")
                        }
                        IconButton(onClick = { viewModel.refresh() }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
                        }
                        IconButton(onClick = {
                            val url = currentTab?.url.orEmpty()
                            if (url.isNotBlank()) {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, url)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share page via"))
                            }
                        }) {
                            Icon(Icons.Filled.Share, contentDescription = "Share")
                        }
                    }
                }
            }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                if (currentTab != null && !currentTab.isHome) {
                    WebViewContainer(
                        tabId = currentTab.id,
                        initialUrl = currentTab.url,
                        getOrCreateWebView = { id, ctx -> getOrCreateWebView(viewModel, id, ctx) },
                        callbacks = callbacks,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (currentTab != null) {
                    HomeScreen(
                        recentHistory = viewModel.history.collectAsState().value,
                        onSearch = { viewModel.navigate(it) },
                        onShortcutClick = { viewModel.navigate(it) },
                        onHistoryItemClick = { viewModel.navigate(it) }
                    )
                }
            }
        }

        // Full-screen video overlay, rendered above the whole scaffold
        fullscreenView?.let { view ->
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { view },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (showLibrarySheet) {
            val bookmarks by viewModel.bookmarks.collectAsState()
            val history by viewModel.history.collectAsState()
            com.techbrowse.app.ui.components.BookmarksHistorySheet(
                bookmarks = bookmarks,
                history = history,
                onOpenUrl = { url -> showLibrarySheet = false; viewModel.navigate(url) },
                onRemoveBookmark = { viewModel.removeBookmark(it) },
                onDismiss = { showLibrarySheet = false }
            )
        }
    }
}

/** Fetches (or lazily creates) the persistent WebView owned by the ViewModel for this tab. */
private fun getOrCreateWebView(viewModel: BrowserViewModel, tabId: String, context: android.content.Context): WebView {
    return viewModel.getWebView(tabId) ?: WebView(context).also {
        it.layoutParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT
        )
        viewModel.registerWebView(tabId, it)
    }
}
