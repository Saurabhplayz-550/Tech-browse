package com.techbrowse.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.techbrowse.app.data.local.BookmarkEntity
import com.techbrowse.app.data.local.HistoryEntity
import com.techbrowse.app.util.hostLabel

/** Bottom sheet showing Bookmarks and History in two tabs, with tap-to-open and swipe-to-remove-style delete icons. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksHistorySheet(
    bookmarks: List<BookmarkEntity>,
    history: List<HistoryEntity>,
    onOpenUrl: (String) -> Unit,
    onRemoveBookmark: (BookmarkEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Bookmarks") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("History") })
        }

        if (selectedTab == 0) {
            if (bookmarks.isEmpty()) {
                EmptyState("No bookmarks yet")
            } else {
                LazyColumn(modifier = Modifier.height(360.dp)) {
                    items(bookmarks, key = { it.id }) { bookmark ->
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .then(Modifier),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f).openable(onOpenUrl, bookmark.url)
                            ) {
                                Text(bookmark.title.ifBlank { hostLabel(bookmark.url) }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    hostLabel(bookmark.url), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            IconButton(onClick = { onRemoveBookmark(bookmark) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Remove bookmark")
                            }
                        }
                        Divider()
                    }
                }
            }
        } else {
            if (history.isEmpty()) {
                EmptyState("No browsing history yet")
            } else {
                LazyColumn(modifier = Modifier.height(360.dp)) {
                    items(history, key = { it.id }) { entry ->
                        Column(
                            modifier = Modifier.fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .openable(onOpenUrl, entry.url)
                        ) {
                            Text(entry.title.ifBlank { hostLabel(entry.url) }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                hostLabel(entry.url), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Text(
        message,
        modifier = Modifier.padding(32.dp),
        color = MaterialTheme.colorScheme.secondary
    )
}

private fun Modifier.openable(onOpenUrl: (String) -> Unit, url: String): Modifier =
    this.then(Modifier.clickable(onClick = { onOpenUrl(url) }))
