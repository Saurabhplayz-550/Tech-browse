package com.techbrowse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.techbrowse.app.navigation.AppNavHost
import com.techbrowse.app.ui.theme.TechBrowseTheme
import com.techbrowse.app.viewmodel.BrowserViewModel
import com.techbrowse.app.viewmodel.BrowserViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels {
        BrowserViewModelFactory((application as TechBrowseApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle a link the app was opened with (e.g. tapping a URL in another app)
        intent?.dataString?.let { url -> viewModel.addTab(url) }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            TechBrowseTheme(theme = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHost(viewModel = viewModel)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
