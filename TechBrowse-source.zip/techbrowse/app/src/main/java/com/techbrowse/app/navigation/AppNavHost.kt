package com.techbrowse.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.techbrowse.app.ui.screens.BrowserScreen
import com.techbrowse.app.ui.screens.SettingsScreen
import com.techbrowse.app.viewmodel.BrowserViewModel

object Routes {
    const val BROWSER = "browser"
    const val SETTINGS = "settings"
}

@Composable
fun AppNavHost(viewModel: BrowserViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.BROWSER) {
        composable(Routes.BROWSER) {
            BrowserScreen(
                viewModel = viewModel,
                onOpenHome = { viewModel.goHome() },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
