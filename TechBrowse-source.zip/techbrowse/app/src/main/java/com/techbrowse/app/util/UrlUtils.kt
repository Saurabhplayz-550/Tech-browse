package com.techbrowse.app.util

import android.util.Patterns
import com.techbrowse.app.data.prefs.SearchEngine
import java.util.regex.Pattern

private val WEB_URL_PATTERN: Pattern = Patterns.WEB_URL

/**
 * Turns whatever the user typed into the address bar into a navigable URL.
 * - If it looks like a domain/URL, normalize it (add scheme if missing).
 * - Otherwise treat it as a search query for the selected engine.
 */
fun resolveInput(input: String, engine: SearchEngine): String {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return "about:blank"

    val looksLikeUrl = trimmed.contains(" ").not() && (
        WEB_URL_PATTERN.matcher(trimmed).matches() ||
            trimmed.startsWith("http://") ||
            trimmed.startsWith("https://") ||
            (trimmed.contains(".") && !trimmed.contains(" "))
        )

    return if (looksLikeUrl) {
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            "https://$trimmed"
        }
    } else {
        engine.queryUrl + java.net.URLEncoder.encode(trimmed, "UTF-8")
    }
}

fun hostLabel(url: String): String = try {
    java.net.URI(url).host ?: url
} catch (e: Exception) {
    url
}
