package com.techbrowse.app.data.repository

import com.techbrowse.app.data.local.AppDatabase
import com.techbrowse.app.data.local.BookmarkEntity
import com.techbrowse.app.data.local.HistoryEntity
import com.techbrowse.app.data.prefs.PreferencesManager
import com.techbrowse.app.data.prefs.SearchEngine
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth for bookmarks, history, and settings.
 * Wraps Room (structured data) and DataStore (key-value prefs).
 */
class BrowserRepository(
    private val db: AppDatabase,
    private val prefs: PreferencesManager
) {
    // Bookmarks
    fun bookmarks(): Flow<List<BookmarkEntity>> = db.bookmarkDao().getAll()

    suspend fun isBookmarked(url: String): Boolean = db.bookmarkDao().findByUrl(url) != null

    suspend fun toggleBookmark(title: String, url: String) {
        val existing = db.bookmarkDao().findByUrl(url)
        if (existing != null) {
            db.bookmarkDao().delete(existing)
        } else {
            db.bookmarkDao().insert(BookmarkEntity(title = title, url = url))
        }
    }

    suspend fun removeBookmark(bookmark: BookmarkEntity) = db.bookmarkDao().delete(bookmark)

    // History
    fun recentHistory(limit: Int = 200): Flow<List<HistoryEntity>> =
        db.historyDao().getRecentLimited(limit)

    suspend fun recordVisit(title: String, url: String) {
        if (url.isBlank() || url == "about:blank") return
        db.historyDao().insert(HistoryEntity(title = title.ifBlank { url }, url = url))
    }

    suspend fun clearHistory() = db.historyDao().clearAll()

    // Settings
    val themeMode: Flow<String> get() = prefs.themeMode
    val searchEngine: Flow<SearchEngine> get() = prefs.searchEngine
    val lastTabsJson: Flow<String?> get() = prefs.lastTabsJson

    suspend fun setThemeMode(mode: String) = prefs.setThemeMode(mode)
    suspend fun setSearchEngine(engine: SearchEngine) = prefs.setSearchEngine(engine)
    suspend fun saveLastTabs(json: String) = prefs.setLastTabsJson(json)
    suspend fun clearLastTabs() = prefs.clearLastTabs()
}
