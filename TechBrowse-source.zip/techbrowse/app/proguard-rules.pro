# WebView JavaScript interfaces (add @JavascriptInterface annotated classes here if introduced later)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.techbrowse.app.data.model.** { *; }
