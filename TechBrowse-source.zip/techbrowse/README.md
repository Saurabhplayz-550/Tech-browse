# Tech Browse — Core Android Source (Kotlin + Jetpack Compose)

A lightweight Chromium-WebView browser, targeting Android 10 (API 29) through Android 17.

## What's included

| Area | File(s) |
|---|---|
| Blue Material 3 theme, light/dark | `ui/theme/Color.kt`, `Theme.kt`, `Type.kt` |
| WebView core (progress, pull-to-refresh, fullscreen video, downloads, popups→tabs) | `ui/components/WebViewContainer.kt` |
| Address bar (URL or search) | `ui/components/AddressBar.kt`, `util/UrlUtils.kt` |
| Multi-tab strip | `ui/components/TabStrip.kt` |
| Browser screen (nav buttons, share, tab/menu bar) | `ui/screens/BrowserScreen.kt` |
| Homepage (search, shortcuts, recent sites) | `ui/screens/HomeScreen.kt` |
| Settings (theme, search engine, clear history/cache) | `ui/screens/SettingsScreen.kt` |
| Bookmarks/History bottom sheet | `ui/components/BookmarksHistorySheet.kt` |
| Room: bookmarks + history persistence | `data/local/*.kt` |
| DataStore: theme, search engine, last-open-tabs | `data/prefs/PreferencesManager.kt` |
| Repository (single source of truth) | `data/repository/BrowserRepository.kt` |
| ViewModel (tabs, nav state, WebView lifecycle) | `viewmodel/BrowserViewModel.kt` |
| Navigation graph | `navigation/AppNavHost.kt` |

## Requirements covered

- **Core Browser**: WebView with `WebChromeClient`/`WebViewClient` for progress %, `PullToRefreshBox`, and full-screen `<video>` via `onShowCustomView`/`onHideCustomView`.
- **Navigation**: Back/Forward/Refresh/Home wired to the active tab's `WebView`; hardware back button also intercepted (`BackHandler`) to navigate the page before exiting.
- **Tabs**: `BrowserViewModel` keeps one real `WebView` per tab id; `target="_blank"` links and `onCreateWindow` open a new tab instead of a popup.
- **Bookmarks / Downloads / Share**: bookmark toggle on the address bar, `DownloadManager` + `setDownloadListener` for file downloads, `Intent.ACTION_SEND` for page sharing.
- **Homepage**: search field, 4 shortcuts (Google/YouTube/ChatGPT/Gmail), recent history list.
- **Settings & storage**: Room for bookmarks/history, DataStore for theme + default search engine + last-open-tabs (restored on cold start); Settings screen includes a theme radio group, search-engine dropdown (Google/Bing/DuckDuckGo), and "Clear history & cache."

## How to open this project

1. Copy the `app/` folder plus `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties` into a new Android Studio project (or open this folder directly as a project root).
2. Sync Gradle — it pulls Compose BOM, Material3, Navigation-Compose, Room+KSP, and DataStore.
3. Add a real app icon (`res/mipmap/ic_launcher*`) — a placeholder isn't included in this source drop.
4. Run on an emulator/device API 29+.

## Notable implementation choices

- **WebView instances live in the ViewModel** (not in Compose `remember`), so switching tabs/screens doesn't reload pages, and `onCleared()` calls `destroy()` on all of them to avoid leaks.
- **`resolveInput()`** decides "is this a URL or a search query" using `Patterns.WEB_URL` plus a few heuristics, then builds the query URL for whichever search engine is selected in Settings.
- **Tab state is persisted as JSON** (kotlinx.serialization) in DataStore on every navigation, and restored on the next cold start — this is the "last opened tabs" requirement.
- Minified/ProGuard rules are stubbed in `app/proguard-rules.pro`.

## Suggested next steps (not included, to keep this a lean core)

- App icon / adaptive icon set.
- Incognito/private tab mode.
- Per-site permissions (camera/mic/geolocation) prompts.
- Find-in-page.
